
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.7.1'
version = '1.7.1'
full_version = '1.7.1'
git_revision = '697316a867a32e9f72778a29226c9febbf867ee8'
release = True

if not release:
    version = full_version
