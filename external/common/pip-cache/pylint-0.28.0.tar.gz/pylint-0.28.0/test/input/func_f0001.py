"""test astng error
"""
import whatever
__revision__ = None
