"""test black listed name
"""

__revision__ = 1

A = None

def baz():
    """yo"""
    pass
