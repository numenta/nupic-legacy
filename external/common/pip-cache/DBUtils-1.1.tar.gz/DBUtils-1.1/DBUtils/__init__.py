# DBUtils package

__all__ = [
    'SimplePooledPg', 'SteadyPg', 'PooledPg', 'PersistentPg',
    'SimplePooledDB', 'SteadyDB', 'PooledDB', 'PersistentDB'
]

__version__ = '1.1'


def InstallInWebKit(appServer):
    pass
